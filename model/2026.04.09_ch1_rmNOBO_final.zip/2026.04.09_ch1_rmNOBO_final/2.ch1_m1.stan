//
// This Stan program defines a hierarchical model
//
// Learn more about model development with Stan at:
//
//    http://mc-stan.org/users/interfaces/rstan.html
//    https://github.com/stan-dev/rstan/wiki/RStan-Getting-Started
//
// Looking for a specific model run previously? check out Z:/Hurlbertlab/Goulden/
// mbbs-analysis and the models that are stored there. They include a txt file 
// with the stan code.
//
data {
  int<lower=0> N; // number of observations or rows
  int<lower=1> Nsp; // number of species
  int<lower=1> Nrt; //number of routes
  int<lower=1> Nyr; //number of years
  int<lower=1> Ndc; //number of diet categories
  array[N] int<lower=1, upper=Nsp> sp; //species id for each observation
  array[N] int<lower=1, upper=Nrt> rt; //route id for each observation
  array[N] int<lower=1, upper=Nyr> year; //year for each observation 
//.............observer section....................................
  vector[N] observer_quality; //there is an observer_quality for every observation [vector of Nobs otherwise]
//..............count................................................
  array[N] int<lower=0> C; // there is a count (my y variable!) for every row, and it is a bounded integer that is at least 0.
//...............predictor variables.....................
  vector[Nsp] t_temp_pos; //temp position value for every species 
  vector[Nsp] t_habitat_selection; //ndvi habitat selection for every species
  vector[Nsp] t_diet; //diet (percent insects) for every species
  vector[Nsp] regional_trend_mean; //mean for each sp regional trend
  vector[Nsp] regional_trend_sd; //sd for each sp regional trend
  
}

parameters {
  
  //intercept
  real a; //universal base intercept, taking the mean out of the intercept distribution and treating it as a constant plus a species and route gaussian distribution centered on zero
  matrix[Nsp, Nrt] a_sprt_raw; //intercept for each unique sp
  real<lower = 0> sig_sprt; //variance in species-specific intercepts
//  vector[Nsp] a_sp_raw; //intercept for each unique sp
//  real<lower = 0> sig_sp; //variance in species-specific intercepts
//  vector[Nrt] a_rt_raw; //intercept for each unique route
//  real<lower = 0> sig_rt; //variance in route-specific intercepts
  
//...............PREV MATRIX METHOD OF INTERCEPT.......................
//  matrix[Nsp, Nrt] a; //species-route interaction matrix, fit a species trend along each sp+rt combo.
//  vector[Nsp] a_bar; // the intercept eg. initial count at yr 0, fit one per species. species-level mean for the intercept a
//  vector<lower=0>[Nsp] sigma_a; //standard deviation in a, if we're fitting a_bar we ought to also fit a species-specific sigma_a... if they all look similar we can re-assess
  //vector[Nsprt] a; //species trend along a specific route, fit one for each sp+rt combo
//................................................................
  
  //calculating species trend year effect slope
  vector[Nsp] b; //species trend, fit one for each species
  real gamma_b; //intercept for the distribution of species trends. calculated across species, and we only want one value, so this is not a vector.
  real<lower = 0> sig_b; //variance in the slope across species, also in some ways deviation from the explanatory power of the traits on predicting trends. Represents residual variance / measure of scatter. In some ways like R2 a bit?
  
  //traits variables predicting betas
  vector[Nsp] regional_trend; //each species has one regional trend, sampled from the mean,sd distribution provided in the data block
  real mu_regional_trend;
  real<lower=0> sigma_regional_trend;
  real kappa_regional; //one effect of regional trend on slopes across species
  real kappa_habitat_selection; //one effect of habitat selectivity on slopes across species
  real kappa_temp_pos; //one effect of temperature niche position on slopes across species
  real kappa_diet; //diet may have one effect on slopes across species.
  
  real c_obs; //effect of observer, calculated across all observers since we use a quantitative measure of observer quality rather than a vector of observer identifiers
  
  real<lower=0> overdispersion_param; //negative binomial overdispersion parameter
  
}

transformed parameters {
  //old matrix method
  //matrix[Nsp, Nrt] a = a_bar + a_z*sigma_a;
  
  //transform z-score easy-to-fit alphas 
  matrix[Nsp, Nrt] a_sprt = a_sprt_raw * sig_sprt;
  //vector[Nsp] a_sp = a_sp_raw * sig_sp;
  //vector[Nrt] a_rt = a_rt_raw * sig_rt;
  
  //vectorize intercept matrix
  vector[N] sprt_intercept;
  for(n in 1:N) {
    sprt_intercept[n] = a_sprt[sp[n], rt[n]];
  }
  
  //vectorize eta
  vector[N] eta = a + sprt_intercept + b[sp] .* to_vector(year) + c_obs * observer_quality;
  
}

model {

//priors first
//intercepts
  a ~ normal(0, 2); //universal intercept, trying not to constrain the prior too lightly so using 2 instead of 1. 
  to_vector(a_sprt_raw) ~ std_normal();
  sig_sprt ~ normal(0, .5); //half normal
//  a_sp_raw ~ std_normal(); //centered on zero, use a hyperparam to set the distribution param.
//  a_rt_raw ~ std_normal(); //^^ same as above
//  sig_rt ~ normal(0, .5); //half normal
//  sig_sp ~ normal(0, .5); //half normal

//observer prior
  c_obs ~ normal(0, 0.5); //half normal, there's one effect of changing observers across routes and species and I don't expect it to be a large effect so I constrain it.
 
//modeling regional trend
//regional trend we already know the mean and standard deviation
//  regional_trend ~ normal(regional_trend_mean, regional_trend_sd); //prev version, updating with Casey's notes:
  mu_regional_trend ~ normal(0, 1.5); 
  //regional trend is scaled and so the mean is now = 0 and has a standard deviation. Varies from -3 to +2
  sigma_regional_trend ~ normal(0, .5); //half normal
  regional_trend ~ normal(mu_regional_trend, sigma_regional_trend);
  regional_trend_mean ~ normal(regional_trend, regional_trend_sd);

 
//kappa priors
//.............BY COMMENTING OUT KAPPAS, DEFAULT UNIFORM PRIORS ARE USED.................
//default uniform priors are not like ultimately reccomended, and since variables are scaled it's not unreasonable to set a normal(0,1) prior, but default uniform Is Workable...
//see: https://github.com/stan-dev/stan/wiki/prior-choice-recommendations
    kappa_regional ~ normal(0, 1);
    kappa_temp_pos ~ normal(0, 1);
    kappa_habitat_selection ~ normal(0, 1);
    kappa_diet ~ normal(0, 1);

//overdispersion param prior
//chatgpt says typical prior for the overdispersion param is a gamma prior. I've seen a beta used as well, some questions remain here.
    overdispersion_param ~ gamma(2,1);
    
//modeling beta
  gamma_b ~ normal(0, 0.2);
  sig_b ~ normal(0, .5); //half normal
  b ~ normal(gamma_b + 
             kappa_regional * regional_trend + 
             kappa_temp_pos * t_temp_pos + 
             kappa_habitat_selection * t_habitat_selection + 
             kappa_diet * t_diet, //categorical so no *
             sig_b);

// Vectorized
C ~ neg_binomial_2_log(eta, overdispersion_param);

}
